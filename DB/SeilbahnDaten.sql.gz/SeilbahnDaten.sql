
-- Erstellen der Tabelle 'SeilbahnDaten'
CREATE TABLE `SeilbahnDaten` (
  `ID` INT NOT NULL AUTO_INCREMENT, -- Automatische ID für jede Zeile
  `Baujahr` INT NOT NULL, -- Jahr, numerisch
  `Typ` VARCHAR(255) NOT NULL, -- Typ als String
  `Standort` VARCHAR(255) NOT NULL, -- Standort als String
  `Hersteller` VARCHAR(255) NOT NULL, -- Hersteller als String
  `HTal` INT NOT NULL, -- Höhe Tal, numerisch
  `HBerg` INT NOT NULL, -- Höhe Berg, numerisch
  `HDiff` INT NOT NULL, -- Höhenunterschied, numerisch
  `HorizontLang` INT NOT NULL, -- Horizontale Länge, numerisch
  `Bodenabstand` INT NOT NULL, -- Bodenabstand, numerisch
  `MaxSpeed` INT NOT NULL, -- Maximale Geschwindigkeit, numerisch
  `MaxFörderleistung` INT NOT NULL, -- Maximale Förderleistung, numerisch
  `Fahrzeit` INT NOT NULL, -- Fahrzeit, numerisch
  `PersproMittel` INT NOT NULL, -- Personen pro Mittel, numerisch
  `ArtGaragierung` VARCHAR(255) NOT NULL, -- Art der Garagierung als String
  `Kuppelbar` BOOLEAN NOT NULL, -- True/False für Kuppelbar
  `Sitzheizung` BOOLEAN NOT NULL, -- True/False für Sitzheizung
  PRIMARY KEY (`ID`)
);

-- Beispiel für das Einfügen von Daten in die Tabelle
INSERT INTO `SeilbahnDaten` (
  `Baujahr`, `Typ`, `Standort`, `Hersteller`, `HTal`, `HBerg`, `HDiff`, 
  `HorizontLang`, `Bodenabstand`, `MaxSpeed`, `MaxFörderleistung`, 
  `Fahrzeit`, `PersproMittel`, `ArtGaragierung`, `Kuppelbar`, `Sitzheizung`
) VALUES (
  2023, 'Gondelbahn', 'Innsbruck', 'Doppelmayr', 850, 2300, 1450,
  2500, 25, 36, 3000, 10, 8, 'Einstellhalle', TRUE, FALSE
);
